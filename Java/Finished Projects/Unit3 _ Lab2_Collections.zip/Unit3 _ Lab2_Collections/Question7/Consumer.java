package Question7;

public interface Consumer<T> {
    void accept(T input);
}