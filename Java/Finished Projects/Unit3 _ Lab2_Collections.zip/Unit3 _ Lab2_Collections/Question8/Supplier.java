package Question8;

public interface Supplier<T> {
    T get();
}
