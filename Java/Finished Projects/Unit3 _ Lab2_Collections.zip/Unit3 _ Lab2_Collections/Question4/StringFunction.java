package Question4;

public interface StringFunction {
    String apply(String input);
}
