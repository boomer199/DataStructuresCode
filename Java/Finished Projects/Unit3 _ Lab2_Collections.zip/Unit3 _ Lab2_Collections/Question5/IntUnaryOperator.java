package Question5;

public interface IntUnaryOperator {
    int apply(int input);
}