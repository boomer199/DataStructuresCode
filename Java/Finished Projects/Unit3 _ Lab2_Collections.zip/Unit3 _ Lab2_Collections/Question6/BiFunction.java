package Question6;

public interface BiFunction<T, U, R> {
    R apply(T input1, U input2);
}
